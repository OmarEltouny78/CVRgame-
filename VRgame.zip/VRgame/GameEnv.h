#pragma once
#include <vector>
#include <string>
#include "Item.h"
using namespace std;
class GameEnv {
private:
	//would use enum instead
	vector<int>scenery;
	int crowd_count;
	bool toggle_view;
	//would use enum instead
	vector<int>direction;
	vector<Item> items;
	vector<int>scenery2D;
	bool turnplayer;
public:
	void setData(vector<int>s, int cr_co, bool t_view, vector<int>dir, vector<Item> it, vector<int>s2D, bool tp) {
		s = scenery;
		cr_co = crowd_count;
		t_view = toggle_view;
		dir = direction;
		it = items;
		s2D = scenery2D;
		tp = turnplayer;
	}
	vector<int> getScenery() {
		return scenery;
	}
	int getCrowdCount() {
		return crowd_count;
	}
	bool getToggleView() {
		return toggle_view;
	}
	vector<int> getDirection() {
		return direction;
	}
	vector<Item> getItems() {
		return items;
	}
	vector<int>getScenery2D() {
		return scenery2D;
	}
	bool getTurnPlayer() {
		return turnplayer;
	}

};