#pragma once
#include <vector>
#include <string>
#include "Tasks.h"
using namespace std;
class Item {
private:
	vector<string> items;
	bool used;
	Task task;
	//set tasks variables 
	void setData(vector<string>is,bool u,Task t ) {
		t = task;
		u = used;
		is = items;
	}
	//Get Item currently being used by player
	vector<string>getItem() {
		return items;
	}
	//if it already been used or not flag
	bool getUsed() {
		return used;
	}
	//Get task which item is a part of
	Task getTask() {
		return task;
	}
};
