#pragma once
#include "Item.h"
class Task{
private:
	int num;
	bool seq;
	Item itemused;
public:
	//set tasks variables 
	void setData(int n,bool s,Item itu) {
		n = num;
		s = seq;
		itu = itemused;
	}
	//Item used to complete task
	Item getItem() {
		return itemused;
	}
	//Number of tasks
	int getNum() {
		return num;
	}
	//Is the task part of a sequence
	bool getSeq() {
		return seq;
	}
};
