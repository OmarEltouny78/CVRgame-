#pragma once
#include <vector>
#include <string>
#include "Tasks.h"
#include "Item.h"
using namespace std;
class PlayerControl{
private:
	int distance;
	vector<Task> tasks;
	bool compTasks;
	vector<Item> items;
	bool compItem;

public:
	//Setter for class PlayerControl
	void setData(int d, vector<Task>t, bool compT, vector<Item> i, bool compI) {
		d = distance;
		t = tasks;
		compT = compTasks;
		i = items;
		compI = compItem;
	}
	//Get Distance Teleported by player
	int getDistance() {
		return distance;
	}
	//List of tasks player has
	vector<Task> getTasks() {
		return tasks;
	}
	//Flag for tasks happened
	bool getCompTasks() {
		return compTasks;
	}
	//List of items had
	vector<Item> getItems() {
		return items;
	}
	//Flag for items
	bool getCompItem() {
		return compItem;
	}

};